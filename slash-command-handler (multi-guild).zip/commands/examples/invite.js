module.exports = {
	name: "invite",
	desc: "Slash Examples",
	run: async(interaction, user, options) => {
		interaction.reply({
			content: 'https://discord.com/api/oauth2/authorize?client_id=934696786008899584&permissions=8&scope=bot%20applications.commands',
			ephemeral: true
		})
	}
}