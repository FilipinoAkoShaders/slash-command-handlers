const Discord = require('discord.js')

module.exports = {
	name: "ping",
	desc: "Replies With Pong!",
	options: [
		{
		name: "pong",
		type: Discord.Constants.ApplicationCommandOptionTypes.STRING,
		description: "Pong!"
	},
		{
			name: "num",
			type: Discord.Constants.ApplicationCommandOptionTypes.NUMBER,
		description: "Num!"
		}
],
	run: async(interaction, user, options) => {
		const pong = options.getString('pong')
    const num = options.getNumber("num")
		interaction.reply({
			content: `Ping! ||<@${user.id}>|| ${pong} ${num} ${user.username}#${user.discriminator}`,
			ephemeral: true
		})
	}
}