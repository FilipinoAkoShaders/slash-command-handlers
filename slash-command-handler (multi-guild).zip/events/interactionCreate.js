const client = require('../index.js')

client.on('interactionCreate', async(interaction) => {
	if(!interaction.isCommand()) return;

	const { commandName, options } = interaction
  
	let cmd = client.commands.get(commandName)
  
  if(cmd) {
		cmd.run(interaction, interaction.user, options)
	}
})