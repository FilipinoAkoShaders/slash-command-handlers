const client = require('../index.js')
const fs = require('fs')
const path = require('path')

client.on('guildCreate', async(guilf) => {
	console.log(`[✅] New Guild ${guild.name}`)
	const guildID = guilf.id
	const guild = client.guilds.cache.get(guildID)
  let command

	if(guild) {
		command = guild.commands
	} else {
		command = client.application?.commands
	}
    console.log(`</> Registering Slash Command To Guild ${guilf.name}`)
	fs.readdirSync(path.join(__dirname).replace('events', 'commands')).forEach(dir => {
		fs.readdirSync(path.join(__dirname).replace('events', `commands/${dir}`)).forEach(file => {
			const pull = require(`../commands/${dir}/${file}`)
			if(!pull.name) return;
      client.commands.set(pull.name, pull)
       command?.create({
				 name: pull.name,
				 description: pull.description || pull.desc || 'No Description',
				 type: pull.type || 1,
				 options: pull.options || []
			 })
       console.log(`</> ${file} Slash Command Been Registered To ${guilf.name}`)
		})
	})
})