const { Client, Intents, Collection } = require('discord.js')
const Database = require('easy-json-database')
const fs = require('fs')
const path = require('path')

const client = new Client({
	intents: [Object.values(Intents.FLAGS).reduce((acc, p) => acc | p, 0)]
})

client.login(process.env.BOT_TOKEN)

client.db = new Database('client-db.json')
client.commands = new Collection()
client.aliases = new Collection()

module.exports = client;

fs.readdirSync(path.join(__dirname + '/handlers')).forEach(file => {
	require(`./handlers/${file}`)
})
console.log('[✅] Handlers Loaded')