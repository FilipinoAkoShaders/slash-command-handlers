const client = require('../index.js')

client.on('ready', async() => {
	client.user.setActivity('Slash Commands')
  console.log(`[✅] ${client.user.tag}Is Ready`)
})