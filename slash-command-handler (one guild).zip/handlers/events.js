const client = require('../index.js')
const fs = require('fs')
const path = require('path')

fs.readdirSync(path.join(__dirname).replace('handlers', 'events')).forEach(file => {
	require(`../events/${file}`)
})
console.log('[✅] Events Ready')