const client = require('../index.js')
const fs = require('fs')
const path = require('path')


client.on('ready', async() => {
	const guildID = '917715237761847348'
	const guild = client.guilds.cache.get(guildID)
  let command

	if(guild) {
		command = guild.commands
	} else {
		command = client.application?.commands
	}
    console.log('</> Registering Slash Command')
	fs.readdirSync(path.join(__dirname).replace('handlers', 'commands')).forEach(dir => {
		fs.readdirSync(path.join(__dirname).replace('handlers', `commands/${dir}`)).forEach(file => {
			const pull = require(`../commands/${dir}/${file}`)
			if(!pull.name) return;
      client.commands.set(pull.name, pull)
       command?.create({
				 name: pull.name,
				 description: pull.description || pull.desc || 'No Description',
				 type: pull.type || 1,
				 options: pull.options || []
			 })
       console.log(`</> ${file} Been Registered To Slash Commands`)
		})
	})
})